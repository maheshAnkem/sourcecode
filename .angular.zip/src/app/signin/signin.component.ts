import { Component, OnInit } from '@angular/core';
import { FormControl , FormGroup} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';


@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.scss']
})
export class SigninComponent implements OnInit {

  testform = new FormGroup({
    name: new FormControl(''),
    email: new FormControl(''),
    password: new FormControl(''),
    number : new FormControl('')
  })

  constructor( private http: HttpClient, private router: Router) { }

  ngOnInit(): void {
  }

  onSubmit() {
    this.http.post<any>('http://localhost:3000/signin',this.testform.value).subscribe(()=>{
     alert("User Regitered successfully!!!")
     this.testform.reset();
     this.router.navigate(['login']);
  });
}

}
